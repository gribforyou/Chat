package ProtocolClasses;

public class Protocol {
    public static final int PORT = 8071;
    public static final int CONNECTION_SUCCESS = 200;
    public static final int CONNECTION_FAILURE = 500;
    public static final int SENDING_MESSAGE_SUCCESS = 201;
    public static final int SENDING_MESSAGE_FAILURE = 400;
}
